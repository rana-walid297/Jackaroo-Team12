package engine.board;

public interface BoardManager {
	
	int getSplitDistance() ;
	
	//Further Info in Board Class Section

}
