package engine;

public interface GameManager {
	
	//Body in Milestone 2

}
